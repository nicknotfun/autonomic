Setting up the Autonomic Controls MCS Sample Program.

Adjust the contents of the Autonomic Controls MCS Main.axs file to match your environment.

The following device and constant values should be reviewed:

	- dvMCS_Port should be an unused IP port on your controller.
	- vdvMCS is the virtual device for MCS and should be an unused virtual device port.
	- dvTP1 should be mapped to your touch panel.
	- cMCS_SERVER_IP is the IP Address of the Mirage Server, or a computer running MCS.
	- iMCE_SERVER_PORT is the control port as set in the Autonomic Configuration Application on the host. (5004 by default on MCS and MMS)
	- iMCE_ART_PORT is the port of the HTTP artwork server as set in the Autonomic Configuration Application. (MCS-5005, MMS-80)

Compile the sample application and load the sample User Interface (TP4) file onto the touch panel using TPDesign4.